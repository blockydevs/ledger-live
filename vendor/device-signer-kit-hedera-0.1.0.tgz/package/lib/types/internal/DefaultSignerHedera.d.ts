import { type DeviceManagementKit, type DeviceSessionId } from "@ledgerhq/device-management-kit";
import { type GetAddressDAReturnType } from "../api/app-binder/GetAddressDeviceActionTypes";
import { type GetAppConfigDAReturnType } from "../api/app-binder/GetAppConfigDeviceActionTypes";
import { type SignTransactionDAReturnType } from "../api/app-binder/SignTransactionDeviceActionTypes";
import { type AddressOptions } from "../api/model/AddressOptions";
import { type AppConfigOptions } from "../api/model/AppConfigOptions";
import { type TransactionOptions } from "../api/model/TransactionOptions";
import { type SignerHedera } from "../api/SignerHedera";
type DefaultSignerHederaConstructorArgs = {
    dmk: DeviceManagementKit;
    sessionId: DeviceSessionId;
};
export declare class DefaultSignerHedera implements SignerHedera {
    private readonly _container;
    constructor({ dmk, sessionId }: DefaultSignerHederaConstructorArgs);
    getAppConfig(options?: AppConfigOptions): GetAppConfigDAReturnType;
    getAddress(derivationPath: string, options?: AddressOptions): GetAddressDAReturnType;
    signTransaction(derivationPath: string, transaction: Uint8Array, options?: TransactionOptions): SignTransactionDAReturnType;
}
export {};
//# sourceMappingURL=DefaultSignerHedera.d.ts.map