export declare const externalTypes: {
    readonly Dmk: symbol;
    readonly SessionId: symbol;
};
//# sourceMappingURL=externalTypes.d.ts.map