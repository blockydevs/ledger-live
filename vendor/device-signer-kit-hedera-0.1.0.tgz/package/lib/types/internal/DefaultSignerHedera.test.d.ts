export {};
//# sourceMappingURL=DefaultSignerHedera.test.d.ts.map