import { type DeviceManagementKit, type DeviceSessionId } from "@ledgerhq/device-management-kit";
import { Container } from "inversify";
type MakeContainerProps = {
    dmk: DeviceManagementKit;
    sessionId: DeviceSessionId;
};
export declare const makeContainer: ({ dmk, sessionId }: MakeContainerProps) => Container;
export {};
//# sourceMappingURL=di.d.ts.map