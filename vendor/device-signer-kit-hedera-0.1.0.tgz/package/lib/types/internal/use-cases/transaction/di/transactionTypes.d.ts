export declare const transactionTypes: {
    readonly SignTransactionUseCase: symbol;
};
//# sourceMappingURL=transactionTypes.d.ts.map