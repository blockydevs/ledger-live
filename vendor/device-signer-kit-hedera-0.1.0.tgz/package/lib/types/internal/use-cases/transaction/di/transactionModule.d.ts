import { ContainerModule } from "inversify";
export declare const transactionModuleFactory: () => ContainerModule;
//# sourceMappingURL=transactionModule.d.ts.map