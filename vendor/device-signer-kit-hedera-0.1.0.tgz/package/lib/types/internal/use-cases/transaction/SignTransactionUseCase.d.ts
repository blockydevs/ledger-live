import { type SignTransactionDAReturnType } from "../../../api/app-binder/SignTransactionDeviceActionTypes";
import { type TransactionOptions } from "../../../api/model/TransactionOptions";
import { HederaAppBinder } from "../../app-binder/HederaAppBinder";
export declare class SignTransactionUseCase {
    private readonly _appBinder;
    constructor(appBinder: HederaAppBinder);
    execute(derivationPath: string, transaction: Uint8Array, options?: TransactionOptions): SignTransactionDAReturnType;
}
//# sourceMappingURL=SignTransactionUseCase.d.ts.map