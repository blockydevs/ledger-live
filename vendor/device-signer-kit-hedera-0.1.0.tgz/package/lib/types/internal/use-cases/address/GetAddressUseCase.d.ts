import { type GetAddressDAReturnType } from "../../../api/app-binder/GetAddressDeviceActionTypes";
import { type AddressOptions } from "../../../api/model/AddressOptions";
import { HederaAppBinder } from "../../app-binder/HederaAppBinder";
export declare class GetAddressUseCase {
    private readonly _appBinder;
    constructor(appBinder: HederaAppBinder);
    execute(derivationPath: string, options?: AddressOptions): GetAddressDAReturnType;
}
//# sourceMappingURL=GetAddressUseCase.d.ts.map