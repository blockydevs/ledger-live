export declare const addressTypes: {
    readonly GetAddressUseCase: symbol;
};
//# sourceMappingURL=addressTypes.d.ts.map