import { ContainerModule } from "inversify";
export declare const addressModuleFactory: () => ContainerModule;
//# sourceMappingURL=addressModule.d.ts.map