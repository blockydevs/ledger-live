export {};
//# sourceMappingURL=GetAppConfigUseCase.test.d.ts.map