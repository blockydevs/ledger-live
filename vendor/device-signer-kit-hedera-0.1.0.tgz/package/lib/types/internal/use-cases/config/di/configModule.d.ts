import { ContainerModule } from "inversify";
export declare const configModuleFactory: () => ContainerModule;
//# sourceMappingURL=configModule.d.ts.map