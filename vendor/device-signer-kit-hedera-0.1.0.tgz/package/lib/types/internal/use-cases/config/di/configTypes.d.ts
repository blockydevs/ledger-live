export declare const configTypes: {
    readonly GetAppConfigUseCase: symbol;
};
//# sourceMappingURL=configTypes.d.ts.map