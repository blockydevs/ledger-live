import { type GetAppConfigDAReturnType } from "../../../api/app-binder/GetAppConfigDeviceActionTypes";
import { type AppConfigOptions } from "../../../api/model/AppConfigOptions";
import { HederaAppBinder } from "../../app-binder/HederaAppBinder";
export declare class GetAppConfigUseCase {
    private readonly _appBinder;
    constructor(appBinder: HederaAppBinder);
    execute(options?: AppConfigOptions): GetAppConfigDAReturnType;
}
//# sourceMappingURL=GetAppConfigUseCase.d.ts.map