export declare const APP_NAME = "Hedera";
export declare const CLA = 224;
export declare const INS: {
    readonly GET_APP_CONFIGURATION: 1;
    readonly GET_PUBLIC_KEY: 2;
    readonly SIGN_TRANSACTION: 4;
};
/** P1 for GET_PUBLIC_KEY: 0x00 shows the key on the device, 0x01 stays silent. */
export declare const P1_CONFIRM = 0;
export declare const P1_NON_CONFIRM = 1;
export declare const P2_UNUSED = 0;
/** Raw Ed25519 public key returned by GET_PUBLIC_KEY. */
export declare const PUBLIC_KEY_LENGTH = 32;
/** Raw Ed25519 signature returned by SIGN_TRANSACTION. */
export declare const SIGNATURE_LENGTH = 64;
/** Little-endian key index that prefixes the GET_PUBLIC_KEY and SIGN_TRANSACTION payloads. */
export declare const KEY_INDEX_LENGTH = 4;
//# sourceMappingURL=constants.d.ts.map