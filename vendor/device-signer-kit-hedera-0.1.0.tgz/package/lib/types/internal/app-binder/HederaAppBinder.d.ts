import { type DeviceManagementKit, type DeviceSessionId } from "@ledgerhq/device-management-kit";
import { type GetAddressDAReturnType } from "../../api/app-binder/GetAddressDeviceActionTypes";
import { type GetAppConfigDAReturnType } from "../../api/app-binder/GetAppConfigDeviceActionTypes";
import { type SignTransactionDAReturnType } from "../../api/app-binder/SignTransactionDeviceActionTypes";
export declare class HederaAppBinder {
    private dmk;
    private sessionId;
    constructor(dmk: DeviceManagementKit, sessionId: DeviceSessionId);
    getAppConfig(args: {
        skipOpenApp: boolean;
    }): GetAppConfigDAReturnType;
    getAddress(args: {
        derivationPath: string;
        checkOnDevice: boolean;
        skipOpenApp: boolean;
    }): GetAddressDAReturnType;
    signTransaction(args: {
        derivationPath: string;
        transaction: Uint8Array;
        skipOpenApp: boolean;
    }): SignTransactionDAReturnType;
}
//# sourceMappingURL=HederaAppBinder.d.ts.map