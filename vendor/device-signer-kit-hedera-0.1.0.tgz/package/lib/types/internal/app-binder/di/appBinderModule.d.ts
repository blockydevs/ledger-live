import { ContainerModule } from "inversify";
export declare const appBindingModuleFactory: () => ContainerModule;
//# sourceMappingURL=appBinderModule.d.ts.map