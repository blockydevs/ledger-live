export declare const appBinderTypes: {
    readonly AppBinding: symbol;
};
//# sourceMappingURL=appBinderTypes.d.ts.map