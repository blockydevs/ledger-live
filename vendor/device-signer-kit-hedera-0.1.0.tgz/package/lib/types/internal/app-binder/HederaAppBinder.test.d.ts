export {};
//# sourceMappingURL=HederaAppBinder.test.d.ts.map