import { type Apdu, type ApduResponse, type Command, type CommandResult } from "@ledgerhq/device-management-kit";
import { type AppConfig } from "../../../api/model/AppConfig";
import { type HederaErrorCodes } from "../../app-binder/command/utils/hederaApplicationErrors";
export type GetAppConfigCommandResponse = AppConfig;
/**
 * Retrieves the configuration of the Hedera application.
 *
 * The device answers with 4 bytes: `[rfu, major, minor, patch]`. The first byte
 * is reserved for future use by the app, is always zero, and is therefore
 * skipped.
 */
export declare class GetAppConfigCommand implements Command<GetAppConfigCommandResponse, void, HederaErrorCodes> {
    readonly name = "GetAppConfig";
    private readonly errorHelper;
    getApdu(): Apdu;
    parseResponse(apduResponse: ApduResponse): CommandResult<GetAppConfigCommandResponse, HederaErrorCodes>;
}
//# sourceMappingURL=GetAppConfigCommand.d.ts.map