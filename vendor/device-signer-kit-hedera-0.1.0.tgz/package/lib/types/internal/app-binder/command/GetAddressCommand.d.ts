import { type Apdu, type ApduResponse, type Command, type CommandResult } from "@ledgerhq/device-management-kit";
import { type Address } from "../../../api/model/Address";
import { type HederaErrorCodes } from "../../app-binder/command/utils/hederaApplicationErrors";
export type GetAddressCommandArgs = {
    readonly derivationPath: string;
    readonly checkOnDevice: boolean;
};
export type GetAddressCommandResponse = Address;
export declare class GetAddressCommand implements Command<GetAddressCommandResponse, GetAddressCommandArgs, HederaErrorCodes> {
    readonly name = "GetAddress";
    private readonly args;
    private readonly errorHelper;
    constructor(args: GetAddressCommandArgs);
    getApdu(): Apdu;
    parseResponse(apduResponse: ApduResponse): CommandResult<GetAddressCommandResponse, HederaErrorCodes>;
}
//# sourceMappingURL=GetAddressCommand.d.ts.map