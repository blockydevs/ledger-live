import { type CommandErrorArgs, type CommandErrors, DeviceExchangeError } from "@ledgerhq/device-management-kit";
export declare enum HederaErrorCodes {
    INTERNAL_ERROR = "6980",
    USER_REJECTED = "6985",
    INS_NOT_SUPPORTED = "6d00",
    MALFORMED_APDU = "6e00",
    SWAP_CHECKING_FAIL = "b00a",
    EMPTY_TRANSACTION = "empty_transaction",
    TRANSACTION_TOO_LARGE = "transaction_too_large",
    UNSUPPORTED_DERIVATION_PATH = "unsupported_derivation_path"
}
export declare const HEDERA_APP_ERRORS: CommandErrors<HederaErrorCodes>;
export declare class HederaAppCommandError extends DeviceExchangeError<HederaErrorCodes> {
    constructor(args: CommandErrorArgs<HederaErrorCodes>);
}
/** Input the app cannot accept, rejected before anything reaches the device. */
export type HederaInvalidInputCode = HederaErrorCodes.EMPTY_TRANSACTION | HederaErrorCodes.TRANSACTION_TOO_LARGE | HederaErrorCodes.UNSUPPORTED_DERIVATION_PATH;
/**
 * Raised while building an APDU, so the caller can tell an input it can fix
 * from a rejection coming back from the device.
 */
export declare class HederaInvalidInputError extends DeviceExchangeError<HederaErrorCodes> {
    constructor(errorCode: HederaInvalidInputCode, message: string);
}
export declare const HederaAppCommandErrorFactory: (args: CommandErrorArgs<HederaErrorCodes>) => HederaAppCommandError;
//# sourceMappingURL=hederaApplicationErrors.d.ts.map