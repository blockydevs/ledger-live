export {};
//# sourceMappingURL=SignTransactionCommand.test.d.ts.map