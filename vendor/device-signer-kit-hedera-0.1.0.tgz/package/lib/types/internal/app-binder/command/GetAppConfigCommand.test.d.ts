export {};
//# sourceMappingURL=GetAppConfigCommand.test.d.ts.map