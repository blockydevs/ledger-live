/**
 * The device app hardcodes the path as m/44'/3030'/0'/0'/index' and takes the
 * index alone, so only paths that fit that shape can be honoured.
 *
 * Two shapes are accepted:
 * - `44'/3030'/0'/0'/index'`, the full path, index taken from the last element.
 * - `44'/3030'`, the shape Ledger Live's `hederaBip44` derivation mode sends,
 *   for which the app assumes index 0.
 *
 * A leading `m/` is optional. Hardening is ignored: the app hardens every
 * element itself, and Ledger Live writes this path unhardened as `44/3030`.
 *
 * @throws HederaInvalidInputError when the path does not fit that shape
 */
export declare function keyIndexFromDerivationPath(derivationPath: string): number;
/** The app reads the key index with U4LE, so it goes on the wire little-endian. */
export declare function encodeKeyIndex(keyIndex: number): Uint8Array;
//# sourceMappingURL=KeyIndexUtils.d.ts.map