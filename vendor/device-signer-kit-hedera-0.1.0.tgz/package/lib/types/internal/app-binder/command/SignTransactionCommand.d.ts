import { type Apdu, type ApduResponse, type Command, type CommandResult } from "@ledgerhq/device-management-kit";
import { type Signature } from "../../../api/model/Signature";
import { HederaErrorCodes } from "../../app-binder/command/utils/hederaApplicationErrors";
/**
 * The app takes the whole transaction body in one APDU, so the key index and
 * the body together have to fit in a single payload.
 */
export declare const MAX_TRANSACTION_LENGTH: number;
export type SignTransactionCommandArgs = {
    readonly derivationPath: string;
    /** Serialized Hedera `TransactionBody` protobuf. */
    readonly transaction: Uint8Array;
};
export type SignTransactionCommandResponse = Signature;
export declare class SignTransactionCommand implements Command<SignTransactionCommandResponse, SignTransactionCommandArgs, HederaErrorCodes> {
    readonly name = "SignTransaction";
    private readonly args;
    private readonly errorHelper;
    constructor(args: SignTransactionCommandArgs);
    getApdu(): Apdu;
    parseResponse(apduResponse: ApduResponse): CommandResult<SignTransactionCommandResponse, HederaErrorCodes>;
}
//# sourceMappingURL=SignTransactionCommand.d.ts.map