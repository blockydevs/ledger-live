import { type DeviceManagementKit, type DeviceSessionId } from "@ledgerhq/device-management-kit";
import { DefaultSignerHedera } from "../internal/DefaultSignerHedera";
type SignerHederaBuilderConstructorArgs = {
    dmk: DeviceManagementKit;
    sessionId: DeviceSessionId;
};
/**
 * Builder for the `SignerHedera` class.
 */
export declare class SignerHederaBuilder {
    private readonly _dmk;
    private readonly _sessionId;
    constructor({ dmk, sessionId }: SignerHederaBuilderConstructorArgs);
    /**
     * Build the signer instance
     *
     * @returns the signer instance
     */
    build(): DefaultSignerHedera;
}
export {};
//# sourceMappingURL=SignerHederaBuilder.d.ts.map