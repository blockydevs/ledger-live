export type TransactionOptions = {
    skipOpenApp?: boolean;
};
//# sourceMappingURL=TransactionOptions.d.ts.map