export type AddressOptions = {
    checkOnDevice?: boolean;
    skipOpenApp?: boolean;
};
//# sourceMappingURL=AddressOptions.d.ts.map