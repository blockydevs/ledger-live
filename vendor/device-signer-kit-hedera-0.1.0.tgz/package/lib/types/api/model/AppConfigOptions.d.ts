export type AppConfigOptions = {
    skipOpenApp?: boolean;
};
//# sourceMappingURL=AppConfigOptions.d.ts.map