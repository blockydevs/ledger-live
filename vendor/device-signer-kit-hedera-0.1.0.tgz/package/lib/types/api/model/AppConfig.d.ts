export type AppConfig = {
    /** Semantic version of the Hedera app running on the device. */
    version: string;
};
//# sourceMappingURL=AppConfig.d.ts.map