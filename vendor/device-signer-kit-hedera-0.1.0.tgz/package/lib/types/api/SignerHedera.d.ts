import { type GetAddressDAReturnType } from "./app-binder/GetAddressDeviceActionTypes";
import { type GetAppConfigDAReturnType } from "./app-binder/GetAppConfigDeviceActionTypes";
import { type SignTransactionDAReturnType } from "./app-binder/SignTransactionDeviceActionTypes";
import { type AddressOptions } from "./model/AddressOptions";
import { type AppConfigOptions } from "./model/AppConfigOptions";
import { type TransactionOptions } from "./model/TransactionOptions";
export interface SignerHedera {
    getAppConfig: (options?: AppConfigOptions) => GetAppConfigDAReturnType;
    getAddress: (derivationPath: string, options?: AddressOptions) => GetAddressDAReturnType;
    signTransaction: (derivationPath: string, transaction: Uint8Array, options?: TransactionOptions) => SignTransactionDAReturnType;
}
//# sourceMappingURL=SignerHedera.d.ts.map