export {};
//# sourceMappingURL=SignerHederaBuilder.test.d.ts.map